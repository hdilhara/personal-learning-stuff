package com.thilina.javatpoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavatpointApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavatpointApplication.class, args);
	}

}
